(function ()
{
    tinymce.create("tinymce.plugins.visionShortcodes",
    {
        init: function ( ed, url )
        {
            ed.addCommand("visionPopup", function ( a, params )
            {
                var popup = params.identifier;
                
                // load thickbox
                tb_show("Insert Shortcode", url + "/vision_popup.php?popup=" + popup + "&width=" + 800);
            });

                var a = this;
                ed.addButton('vision_button', {
                title: "Insert Shortcode",
                icon: '" style="background: url(http://s3.truethemes.net/truethemes-framework/vision-btn.png);"',
                image: "http://s3.truethemes.net/truethemes-framework/vision-btn.png",
                type: 'splitbutton',
                menu: [
                	//# start: modified by Arlind Nushi
                    a.addWithPopup(ed, "Columns", "lab-columns"),
                    a.addImmediate(ed, "Breadcrumb", "[lab_breadcrumb]"),
                    a.addImmediate(ed, "Clear Row", "[lab_clear]"),
                    a.addWithPopup(ed, "Alert Message", "lab-alert"),
                    a.addWithPopup(ed, "Button", "lab-button"),
                    a.addWithPopup(ed, "Pricing Box", "lab-pricing-box"),
                    a.addWithPopup(ed, "Tabs", "lab-tabs"),
                    //# end: modified by Arlind Nushi
                    
                ]
            });
        },
        
		addWithPopup: function ( ed, title, id ) {
            return{
                text: title,
                onclick: function () {
                    tinyMCE.activeEditor.execCommand("visionPopup", false, {
                        title: title,
                        identifier: id
                    })
                }
            };
        },
        addImmediate: function ( ed, title, sc) {
        	return{
                text: title,
                onclick: function () {
                    tinyMCE.activeEditor.execCommand( "mceInsertContent", false, sc );
                }
            };
        },
        getInfo: function () {
            return {
                longname: 'Vision Shortcodes',
                author: 'TrueThemes',
                authorurl: 'http://themeforest.net/user/truethemes/',
                infourl: 'http://wiki.moxiecode.com/',
                version: "1.0"
            }
        }
    });
    
    // add ttShortcodes plugin
    tinymce.PluginManager.add("visionShortcodes", tinymce.plugins.visionShortcodes);
})();